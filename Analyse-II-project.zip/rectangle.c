#include <stdio.h>
#include <math.h>

// Function prototypes
double linear_function(double x);
double quadratic_function(double x);
double cubic_function(double x);
double sine_function(double x);
double exponential_function(double x);
double logarithmic_function(double x);

// Function to integrate using the Rectangle Method
double rectangle_method(double (*f)(double), double a, double b, int n) {
    double h = (b - a) / n;
    double result = 0.0;

    for (int i = 0; i < n; ++i) {
        result += f(a + i * h);
    }

    return result * h;
}

int main() {
    double a, b;
    int n;
    int choice;

    // Input
    printf("Enter the interval [A, B]: ");
    if (scanf("%lf %lf", &a, &b) != 2) {
        printf("Invalid input. Exiting.\n");
        return 1;
    }

    // Ensure valid input for subintervals
    printf("Enter the number of subintervals: ");
    if (scanf("%d", &n) != 1 || n < 1) {
        printf("Invalid input for subintervals. Exiting.\n");
        return 1;
    }

    // Function selection
    printf("Select a function to integrate:\n");
    printf("1. Linear Function\n");
    printf("2. Quadratic Function\n");
    printf("3. Cubic Function\n");
    
    printf("Enter your choice (1-6): ");
    if (scanf("%d", &choice) != 1 || choice < 1 || choice > 6) {
        printf("Invalid function choice. Exiting.\n");
        return 1;
    }

    // Calculate and display the result based on user's function choice
    double result;
    switch (choice) {
        case 1:
            result = rectangle_method(linear_function, a, b, n);
            break;
        case 2:
            result = rectangle_method(quadratic_function, a, b, n);
            break;
        case 3:
            result = rectangle_method(cubic_function, a, b, n);
            break;
      
        default:
            printf("Invalid function choice. Exiting.\n");
            return 1;
    }

    printf("Approximate integral using Rectangle Method: %lf\n", result);

    return 0;
}

// Function implementations (same as in the previous programs)
// ...

