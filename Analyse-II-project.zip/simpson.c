#include <stdio.h>
#include <math.h>

// Function prototypes
double linear_function(double x);
double quadratic_function(double x);
double cubic_function(double x);
double sine_function(double x);
double exponential_function(double x);
double logarithmic_function(double x);

// Function to integrate using Simpson's Method
double simpsons_method(double (*f)(double), double a, double b, int n) {
    double h = (b - a) / n;
    double result = f(a) + f(b);

    for (int i = 1; i < n; i += 2) {
        result += 4 * f(a + i * h);
    }

    for (int i = 2; i < n - 1; i += 2) {
        result += 2 * f(a + i * h);
    }

    return result * h / 3.0;
}

int main() {
    double a, b;
    int n;
    int choice;

    // Input
    printf("Enter the interval [A, B]: ");
    if (scanf("%lf %lf", &a, &b) != 2) {
        printf("Invalid input. Exiting.\n");
        return 1;
    }

    // Ensure valid input for subintervals (must be even)
    printf("Enter the number of subintervals (even): ");
    if (scanf("%d", &n) != 1 || n % 2 != 0) {
        printf("Invalid input for subintervals. Exiting.\n");
        return 1;
    }

    // Function selection
    printf("Select a function to integrate:\n");
    printf("1. Linear Function\n");
    printf("2. Quadratic Function\n");
    printf("3. Cubic Function\n");
    printf("4. Sine Function\n");
    printf("5. Exponential Function\n");
    printf("6. Logarithmic Function\n");
    printf("Enter your choice (1-6): ");
    if (scanf("%d", &choice) != 1 || choice < 1 || choice > 6) {
        printf("Invalid function choice. Exiting.\n");
        return 1;
    }

    // Calculate and display the result based on user's function choice
    double result;
    switch (choice) {
        case 1:
            result = simpsons_method(linear_function, a, b, n);
            break;
        case 2:
            result = simpsons_method(quadratic_function, a, b, n);
            break;
        case 3:
            result = simpsons_method(cubic_function, a, b, n);
            break;
        case 4:
            result = simpsons_method(sine_function, a, b, n);
            break;
        case 5:
            result = simpsons_method(exponential_function, a, b, n);
            break;
        case 6:
            result = simpsons_method(logarithmic_function, a, b, n);
            break;
        default:
            printf("Invalid function choice. Exiting.\n");
            return 1;
    }

    printf("Approximate integral using Simpson's Method: %lf\n", result);

    return 0;
}

// Function implementations
double linear_function(double x) {
    return 2 * x + 3;
}

double quadratic_function(double x) {
    return 3 * x * x - 2 * x + 1;
}

double cubic_function(double x) {
    return x * x * x + 4 * x * x - 2 * x + 5;
}

double sine_function(double x) {
    return sin(x);
}

double exponential_function(double x) {
    return exp(x);
}

double logarithmic_function(double x) {
    return log(x + 1);
}

