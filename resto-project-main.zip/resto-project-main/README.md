# resto-project
It is one of the projects my friends and i deed (Jason, Arthur, Parfait and I, Dexter)
it is a simple restaurant project with HTML, CSS, and JS.
The project is beeing continuesly developed, feel free to contribute, and or even better we will love a feedback
